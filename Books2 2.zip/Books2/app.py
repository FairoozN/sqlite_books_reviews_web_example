from flask import Flask, jsonify, render_template, request
import sqlite3
import pymongo


app = Flask(__name__)

DATABASE = 'db/books.db'
app.config['DATABASE'] = DATABASE

# MongoDB connection
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client['book_database']  # MongoDB database
reviews_collection = db['reviews']  # MongoDB collection for reviews

def get_db_connection():
    """Return a database connection using the configured DATABASE path."""
    db_path = app.config.get('DATABASE', DATABASE)
    return sqlite3.connect(db_path)


@app.route('/api/books', methods=['GET'])
def get_all_books():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT B.book_id, B.title, B.publication_year, A.name, B.image_url
            FROM Books B
            LEFT JOIN book_author BA ON B.book_id = BA.book_id
            LEFT JOIN Authors A ON BA.author_id = A.author_id
        ''')
        books = cursor.fetchall()
        conn.close()

        book_list = [{
            'book_id': b[0],
            'title': b[1],
            'publication_year': b[2],
            'author': b[3],
            'image_url': b[4]
        } for b in books]

        return jsonify({'books': book_list})
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/authors', methods=['GET'])
def get_all_authors():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Authors")
        authors = cursor.fetchall()
        conn.close()
        return jsonify(authors)
    except Exception as e:
        return jsonify({'error': str(e)})


# @app.route('/api/reviews', methods=['GET'])
# def get_all_reviews():
#     try:
#         conn = get_db_connection()
#         cursor = conn.cursor()
#         cursor.execute("SELECT * FROM Reviews")
#         reviews = cursor.fetchall()
#         conn.close()
#         return jsonify(reviews)
#     except Exception as e:
#         return jsonify({'error': str(e)})


# API to get all reviews from MongoDB
@app.route('/api/reviews', methods=['GET'])
def get_all_reviews():
    try:
        reviews = list(reviews_collection.find({}, {'_id': 0}))  # Get all reviews from MongoDB
        return jsonify({'reviews': reviews})
    except Exception as e:
        return jsonify({'error': str(e)})

# API to add a new review to MongoDB
@app.route('/api/add_review', methods=['POST'])
def add_review():
    try:
        data = request.get_json()  # Get review details from the request
        book_id = data.get('book_id')
        user = data.get('user')
        rating = data.get('rating')
        comment = data.get('comment')

        # Insert the review into the MongoDB collection
        review = {
            'book_id': book_id,
            'user': user,
            'rating': rating,
            'comment': comment
        }
        reviews_collection.insert_one(review)

        return jsonify({'message': 'Review added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/add_book', methods=['POST'])
def add_book():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        data = request.get_json()
        title = data.get('title')
        publication_year = data.get('publication_year')
        author_name = data.get('author')
        image_url = data.get('image_url')

    
        if not title or not author_name:
            return jsonify({'error': 'Title and Author are required fields.'}), 400


        cursor.execute(
            "INSERT INTO Books (title, publication_year, image_url) VALUES (?, ?, ?)",
            (title, publication_year, image_url)
        )
        book_id = cursor.lastrowid

        
        cursor.execute("SELECT author_id FROM Authors WHERE name = ?", (author_name,))
        row = cursor.fetchone()
        if row:
            author_id = row[0]
        else:
            cursor.execute("INSERT INTO Authors (name) VALUES (?)", (author_name,))
            author_id = cursor.lastrowid

        
        cursor.execute("INSERT INTO book_author (book_id, author_id) VALUES (?, ?)", (book_id, author_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Book and Author added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/search', methods=['GET'])
def search_books():
    try:
        query = request.args.get('q', '').strip()
        print(f"Search query received: {query}")

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT B.book_id, B.title, B.publication_year, A.name, B.image_url
            FROM Books B
            LEFT JOIN book_author BA ON B.book_id = BA.book_id
            LEFT JOIN Authors A ON BA.author_id = A.author_id
            WHERE B.title LIKE ? OR A.name LIKE ?
        ''', (f'%{query}%', f'%{query}%'))
        books = cursor.fetchall()
        conn.close()

        book_list = [{
            'book_id': b[0],
            'title': b[1],
            'publication_year': b[2],
            'author': b[3],
            'image_url': b[4]
        } for b in books]

        return jsonify({'books': book_list})
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    print("Running on port 5001")
    app.run(debug=True, host="0.0.0.0", port=5001)
